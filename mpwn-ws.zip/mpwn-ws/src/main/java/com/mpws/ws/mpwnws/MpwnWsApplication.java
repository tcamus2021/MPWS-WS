package com.mpws.ws.mpwnws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MpwnWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MpwnWsApplication.class, args);
	}

}
