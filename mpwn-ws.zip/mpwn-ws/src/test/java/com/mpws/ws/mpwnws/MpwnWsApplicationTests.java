package com.mpws.ws.mpwnws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MpwnWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
